create view EMP_SENIORITY_VIEW as
SELECT ename, hiredate
FROM emp
/

