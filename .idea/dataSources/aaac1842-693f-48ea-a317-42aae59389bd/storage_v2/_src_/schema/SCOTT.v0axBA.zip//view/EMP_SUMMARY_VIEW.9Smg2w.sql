create view EMP_SUMMARY_VIEW as
SELECT ename, job, dname, loc
FROM  EMP JOIN DEPT D on EMP.DEPTNO = D.DEPTNO
/

