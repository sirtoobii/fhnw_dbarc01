create view EMP_FUNCTION_DEMO_VIEW (ENAME, SAL) as
SELECT concat(ENAME, JOB), SAL
   FROM emp
/

