create view EMP_DEPT_VIEW as
SELECT empno, ename, dname
   FROM EMP JOIN DEPT USING (deptno)
/

