create view EMP_SALES_VIEW as
SELECT empno,ename, deptno,job,sal
    FROM EMP WHERE DEPTNO = 30
/

