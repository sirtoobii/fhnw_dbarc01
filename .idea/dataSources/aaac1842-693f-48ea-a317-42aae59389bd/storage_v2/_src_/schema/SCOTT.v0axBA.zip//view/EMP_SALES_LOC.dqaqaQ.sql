create view EMP_SALES_LOC as
SELECT empno, ename, deptno, job, sal,loc
FROM emp_sales_view JOIN DEPT USING(deptno)
/

